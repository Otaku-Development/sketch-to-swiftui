import UIKit
/*
var greeting = "Hello, playground"

struct Rectangle {
    var x: Double // x-coordinate
    var y: Double // y-coordinate
    var width: Double
    var height: Double
}

//func combineRectangles(_ rect1: Rectangle, _ rect2: Rectangle) -> Rectangle {
//    let minX = min(rect1.x, rect2.x)
//    let minY = min(rect1.y, rect2.y)
//    let maxX = max(rect1.x + rect1.width, rect2.x + rect2.width)
//    let maxY = max(rect1.y + rect1.height, rect2.y + rect2.height)
//
//    // Calculate the center of the combined rectangle
//    let centerX = (minX + maxX) / 2.0
//    let centerY = (minY + maxY) / 2.0
//
//    let combinedWidth = maxX - minX
//    let combinedHeight = maxY - minY
//
//    return Rectangle(x: centerX - combinedWidth / 2.0, y: centerY - combinedHeight / 2.0, width: combinedWidth, height: combinedHeight)
//}
func combineRectangles(_ rect1: Rectangle, _ rect2: Rectangle) -> Rectangle {
    let minX = min(rect1.x, rect2.x)
    let minY = min(rect1.y, rect2.y)
    let maxX = max(rect1.x + rect1.width, rect2.x + rect2.width)
    let maxY = max(rect1.y + rect1.height, rect2.y + rect2.height)

    let combinedWidth = maxX - minX
    let combinedHeight = maxY - minY

    let centerX = minX + combinedWidth / 2.0
    let centerY = minY + combinedHeight / 2.0

    return Rectangle(x: centerX - combinedWidth / 2.0, y: centerY - combinedHeight / 2.0, width: combinedWidth, height: combinedHeight)
}

// Example usage:
let rect1 = Rectangle(x: 0.2, y: 0.3, width: 0.4, height: 0.5)
let rect2 = Rectangle(x: 0.4, y: 0.2, width: 0.6, height: 0.7)

let combinedRect = combineRectangles(rect1, rect2)
print("Combined Rectangle: x=\(combinedRect.x), y=\(combinedRect.y), width=\(combinedRect.width), height=\(combinedRect.height)")
*/
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        NavigationStack {
            List {
                Text("Hello World")
            }
            .navigationTitle("Navigation Title")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        print("Custom Action")
                    } label: {
                        HStack {
                            Image(systemName: "chevron.backward")
                            Text("Back")
                        }
                    }
                    .tint(.white)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        print("Custom Action")
                    } label: {
                        HStack {
//                            Image(systemName: "chevron.backward")
                            Text("Done")
                        }
                    }
                    .tint(.white)
                }
            }
            .navigationTitle("Navigation Title")
            .toolbarBackground(
                Color.pink,
                for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
